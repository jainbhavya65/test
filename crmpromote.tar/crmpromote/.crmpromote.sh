#!/bin/bash
#########################################################################################
crmpromote()
{
bash /usr/local/src/test/crmpromote/replace_revise.sh
}
